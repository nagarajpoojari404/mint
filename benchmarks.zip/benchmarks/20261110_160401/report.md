# Mint parallelism benchmark

_Generated 2026-11-10 16:04:01 on `a0f548ec00b5`_

## 1. Environment

| Item | Value |
|:--|--:|
| GPUs | 2 × Tesla T4 |
| GPU memory | 15.0 GB each |
| Driver / compute cap. | 580.178.04 / 7.5 |
| PyTorch / CUDA | 2.12.0+cu130 / 13.0 |
| Autocast dtype | float16 |
| Peak used for MFU | 65 TFLOPS per GPU (rated dense FP16/BF16 tensor-core) |
| Sequence length | 128 |
| Timed steps / warmup | 10 / 3 |
| Optimizer step | DistMuonAdamW + grad clip 1.0 + GradScaler |
| Python | 3.13.16 |

<details><summary>GPU interconnect topology (<code>nvidia-smi topo -m</code>)</summary>

```
[4mGPU0	GPU1	CPU Affinity	NUMA Affinity	GPU NUMA ID[0m
GPU0	 X 	PHB	0-3	0		N/A
GPU1	PHB	 X 	0-3	0		N/A

Legend:

  X    = Self
  SYS  = Connection traversing PCIe as well as the SMP interconnect between NUMA nodes (e.g., QPI/UPI)
  NODE = Connection traversing PCIe as well as the interconnect between PCIe Host Bridges within a NUMA node
  PHB  = Connection traversing PCIe as well as a PCIe Host Bridge (typically the CPU)
  PXB  = Connection traversing multiple PCIe bridges (without traversing the PCIe Host Bridge)
  PIX  = Connection traversing at most a single PCIe bridge
  NV#  = Connection traversing a bonded set of # NVLinks
```
</details>

## 2. Methodology

- **Modes**: `single` (1 GPU) · `ddp0..3` (data parallel over all GPUs; ZeRO level 0/1/2/3) · `tp` / `tp_sp` (tensor parallel over all GPUs without / with sequence parallel). TP and DDP are never combined.
- **Micro-batch (mb)** is *per data-parallel replica*. DDP/ZeRO therefore scale the global batch with the GPU count (weak scaling); TP runs process one batch jointly, so its global batch equals `single`.
- **tok/s** is global (all GPUs). **TFLOPS** = model FLOPs/token × tok/s (6 FLOPs per matmul param + attention, real vocab; padding and recompute excluded). **MFU** = TFLOPS per GPU ÷ rated peak.
- **Scaling efficiency** = (tok/s ÷ single-GPU tok/s) ÷ GPU count. For TP this is below 1 by design: TP buys memory headroom, not throughput, at this scale.
- **Memory** is `torch.cuda.max_memory_allocated` per GPU over the timed steps (max across ranks).
- **GPU util / mem-ctrl util / power / SM clock / temp** are `nvidia-smi` samples (100 ms) taken on every GPU during the timed steps. *GPU util* is the share of time any kernel is running, not SM occupancy.
- **Kernel busy / matmul / attention / NCCL / other** come from `torch.profiler` over 3 extra steps; kernels are classified by name (heuristic). Busy % can saturate at 100 when kernels overlap on several streams. NCCL share is communication time, including overlapped time.
- `[eager]` marks runs where the *model* was not `torch.compile`d (compile failed, or unsupported with ZeRO-3), so they are not directly comparable with compiled runs. The loss is compiled unless `--no-compile` is used; the optimizer's fused kernels are always compiled.

## 3. Summary

| Shape | MB | Fastest mode | tok/s | TFLOPS (total) | MFU | vs 1 GPU |
|:--|--:|--:|--:|--:|--:|--:|
| `128:128:8:8:2` | 64 | DDP (ZeRO-0) | 210,147 | 11.58 | 8.9% | 1.72× |
| `128:128:8:8:2` | 128 | DDP (ZeRO-0) | 255,550 | 14.09 | 10.8% | 1.87× |
| `256:1024:8:4:2` | 64 | DDP (ZeRO-0) | 151,463 | 19.32 | 14.9% | 1.78× |
| `256:1024:8:4:2` | 128 | DDP (ZeRO-0) | 167,740 | 21.39 | 16.5% | 1.86× |
| `384:1536:8:6:2` | 64 | DDP (ZeRO-0) | 97,918 | 21.97 | 16.9% | 1.72× |
| `384:1536:8:6:2` | 128 | DDP (ZeRO-0) | 109,652 | 24.60 | 18.9% | 1.84× |
| `512:2048:8:8:2` | 64 | DDP (ZeRO-0) | 69,192 | 23.74 | 18.3% | 1.70× |
| `512:2048:8:8:2` | 128 | DDP (ZeRO-0) | 77,927 | 26.74 | 20.6% | 1.84× |
| `512:2048:12:8:2` | 64 | DDP (ZeRO-0) | 52,061 | 22.78 | 17.5% | 1.73× |
| `512:2048:12:8:2` | 128 | DDP (ZeRO-0) | 57,972 | 25.36 | 19.5% | 1.82× |
| `768:3072:12:12:4` | 64 | DDP (ZeRO-0) | 28,795 | 25.01 | 19.2% | 1.73× |
| `768:3072:12:12:4` | 128 | DDP (ZeRO-0) | 30,533 | 26.52 | 20.4% | 1.82× |

**Key observations**

- Fastest multi-GPU mode (by global tok/s): **DDP (ZeRO-0)** in 12/12 cells.
- ZeRO-1 (opt state) peak memory is **0.97×** DDP-0 on average (-3%).
- ZeRO-2 (+grads) peak memory is **0.97×** DDP-0 on average (-3%).
- ZeRO-3 (+params) peak memory is **1.30×** DDP-0 on average (+30%).
- Best data-parallel mode is **1.52×** the best tensor-parallel mode in tok/s on average.
- Adding sequence parallelism changes TP throughput by **0.70×** on average.

## 4. Model sizes

| Shape | d | hidden | layers | heads | kv | Params M | Non-emb M | fp32 MB | MFLOPs/token (train) |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| `128:128:8:8:2` | 128 | 128 | 8 | 8 | 2 | 8.1 | 1.7 | 33 | 55.1 |
| `256:1024:8:4:2` | 256 | 1024 | 8 | 4 | 2 | 20.8 | 7.9 | 83 | 127.5 |
| `384:1536:8:6:2` | 384 | 1536 | 8 | 6 | 2 | 36.6 | 17.3 | 147 | 224.3 |
| `512:2048:8:8:2` | 512 | 2048 | 8 | 8 | 2 | 56.2 | 30.4 | 225 | 343.2 |
| `512:2048:12:8:2` | 512 | 2048 | 12 | 8 | 2 | 71.4 | 45.6 | 286 | 437.5 |
| `768:3072:12:12:4` | 768 | 3072 | 12 | 12 | 4 | 142.5 | 103.8 | 570 | 868.6 |

## 5. Results by shape and micro-batch

### `128:128:8:8:2` · 8.1M params · mb=64

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 67 | 122,102 | 122,102 | 6.73 | 6.73 | 10.4% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 78 | 210,147 | 105,074 | 11.58 | 5.79 | 8.9% | 1.72× | 86% |  |
| ZeRO-1 (opt state) | 2 | 106 | 154,886 | 77,443 | 8.54 | 4.27 | 6.6% | 1.27× | 63% |  |
| ZeRO-2 (+grads) | 2 | 103 | 158,511 | 79,255 | 8.74 | 4.37 | 6.7% | 1.30× | 65% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 178 | 91,884 | 45,942 | 5.06 | 2.53 | 3.9% | 0.75× | 38% |  |
| TP=2 | 2 | 69 | 119,357 | 59,679 | 6.58 | 3.29 | 5.1% | 0.98× | 49% |  |
| TP=2+SP | 2 | 93 | 87,701 | 43,850 | 4.83 | 2.42 | 3.7% | 0.72× | 36% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.033 | 0.065 | 0.12 | 2.37 | 3.23 | – |
| DDP (ZeRO-0) | 0.033 | 0.065 | 0.12 | 2.37 | 3.23 | +0% |
| ZeRO-1 (opt state) | 0.033 | 0.033 | 0.08 | 2.34 | 2.40 | -1% |
| ZeRO-2 (+grads) | 0.033 | 0.033 | 0.08 | 2.34 | 2.40 | -1% |
| ZeRO-3 (+params) | 0.016 | 0.033 | 0.07 | 2.85 | 2.89 | +20% |
| TP=2 | 0.029 | 0.058 | 0.11 | 2.13 | 2.98 | -10% |
| TP=2+SP | 0.029 | 0.058 | 0.11 | 2.09 | 2.94 | -12% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 73% | 61% | 63 | 1175 | 50 | 95% | 23% | 12% | 0% | 65% |
| DDP (ZeRO-0) | 76% | 52% | 57 | 1242 | 49 | 100% | 19% | 10% | 17% | 54% |
| ZeRO-1 (opt state) | 77% | 43% | 54 | 1280 | 50 | 100% | 10% | 5% | 38% | 47% |
| ZeRO-2 (+grads) | 77% | 43% | 72 | 1253 | 51 | 100% | 11% | 6% | 35% | 49% |
| ZeRO-3 (+params) | 78% | 59% | 62 | 1435 | 53 | 79% | 7% | 4% | 48% | 41% |
| TP=2 | 68% | 52% | 62 | 1248 | 54 | 100% | 18% | 6% | 19% | 57% |
| TP=2+SP | 77% | 41% | 65 | 1392 | 56 | 100% | 10% | 3% | 53% | 33% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 78 | 2.37 | 3.23 | 80% | 49% | 55 | 1281 | 100% | 18% |
| DDP (ZeRO-0) | GPU 1 | 78 | 2.37 | 3.23 | 73% | 54% | 60 | 1202 | 100% | 16% |
| ZeRO-1 (opt state) | GPU 0 | 106 | 2.34 | 2.40 | 90% | 43% | 41 | 1263 | 100% | 37% |
| ZeRO-1 (opt state) | GPU 1 | 106 | 2.34 | 2.40 | 64% | 44% | 68 | 1297 | 100% | 39% |
| ZeRO-2 (+grads) | GPU 0 | 103 | 2.34 | 2.40 | 68% | 42% | 62 | 1200 | 100% | 51% |
| ZeRO-2 (+grads) | GPU 1 | 103 | 2.34 | 2.40 | 87% | 43% | 83 | 1307 | 100% | 19% |
| ZeRO-3 (+params) | GPU 0 | 178 | 2.85 | 2.89 | 77% | 59% | 62 | 1428 | 100% | 73% |
| ZeRO-3 (+params) | GPU 1 | 178 | 2.85 | 2.89 | 80% | 60% | 61 | 1443 | 59% | 22% |
| TP=2 | GPU 0 | 69 | 2.13 | 2.98 | 64% | 49% | 59 | 1178 | 100% | 18% |
| TP=2 | GPU 1 | 69 | 2.13 | 2.98 | 74% | 54% | 65 | 1318 | 100% | 20% |
| TP=2+SP | GPU 0 | 93 | 2.09 | 2.94 | 81% | 41% | 66 | 1453 | 100% | 63% |
| TP=2+SP | GPU 1 | 93 | 2.09 | 2.94 | 74% | 41% | 64 | 1330 | 100% | 44% |

</details>

### `128:128:8:8:2` · 8.1M params · mb=128

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 120 | 136,713 | 136,713 | 7.54 | 7.54 | 11.6% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 128 | 255,550 | 127,775 | 14.09 | 7.04 | 10.8% | 1.87× | 93% |  |
| ZeRO-1 (opt state) | 2 | 152 | 215,480 | 107,740 | 11.88 | 5.94 | 9.1% | 1.58× | 79% |  |
| ZeRO-2 (+grads) | 2 | 149 | 219,190 | 109,595 | 12.08 | 6.04 | 9.3% | 1.60× | 80% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 265 | 123,735 | 61,868 | 6.82 | 3.41 | 5.2% | 0.91× | 45% |  |
| TP=2 | 2 | 112 | 145,841 | 72,920 | 8.04 | 4.02 | 6.2% | 1.07× | 53% |  |
| TP=2+SP | 2 | 158 | 103,852 | 51,926 | 5.72 | 2.86 | 4.4% | 0.76× | 38% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.033 | 0.065 | 0.12 | 4.62 | 6.29 | – |
| DDP (ZeRO-0) | 0.033 | 0.065 | 0.12 | 4.62 | 6.29 | +0% |
| ZeRO-1 (opt state) | 0.033 | 0.033 | 0.08 | 4.58 | 4.67 | -1% |
| ZeRO-2 (+grads) | 0.033 | 0.033 | 0.08 | 4.58 | 4.67 | -1% |
| ZeRO-3 (+params) | 0.016 | 0.033 | 0.07 | 5.55 | 7.21 | +20% |
| TP=2 | 0.029 | 0.058 | 0.11 | 4.15 | 4.22 | -10% |
| TP=2+SP | 0.029 | 0.058 | 0.11 | 4.06 | 5.74 | -12% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 85% | 77% | 68 | 1020 | 64 | 98% | 29% | 16% | 0% | 55% |
| DDP (ZeRO-0) | 86% | 71% | 64 | 1062 | 56 | 100% | 25% | 14% | 14% | 48% |
| ZeRO-1 (opt state) | 83% | 63% | 62 | 1128 | 57 | 100% | 16% | 9% | 30% | 45% |
| ZeRO-2 (+grads) | 86% | 65% | 60 | 1096 | 57 | 100% | 16% | 9% | 32% | 43% |
| ZeRO-3 (+params) | 90% | 81% | 66 | 1266 | 58 | 100% | 10% | 5% | 34% | 49% |
| TP=2 | 82% | 66% | 58 | 978 | 58 | 100% | 25% | 8% | 18% | 50% |
| TP=2+SP | 88% | 55% | 66 | 1254 | 58 | 100% | 14% | 4% | 52% | 29% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 128 | 4.62 | 6.29 | 85% | 72% | 64 | 983 | 100% | 11% |
| DDP (ZeRO-0) | GPU 1 | 128 | 4.62 | 6.29 | 87% | 70% | 64 | 1141 | 100% | 16% |
| ZeRO-1 (opt state) | GPU 0 | 152 | 4.58 | 4.67 | 89% | 63% | 67 | 1064 | 100% | 46% |
| ZeRO-1 (opt state) | GPU 1 | 152 | 4.58 | 4.67 | 77% | 63% | 56 | 1192 | 100% | 14% |
| ZeRO-2 (+grads) | GPU 0 | 149 | 4.58 | 4.67 | 84% | 64% | 62 | 1074 | 100% | 12% |
| ZeRO-2 (+grads) | GPU 1 | 149 | 4.58 | 4.67 | 88% | 66% | 58 | 1118 | 100% | 51% |
| ZeRO-3 (+params) | GPU 0 | 265 | 5.55 | 7.21 | 89% | 81% | 68 | 1195 | 100% | 22% |
| ZeRO-3 (+params) | GPU 1 | 265 | 5.55 | 7.21 | 90% | 82% | 64 | 1338 | 100% | 46% |
| TP=2 | GPU 0 | 112 | 4.15 | 4.22 | 86% | 67% | 59 | 893 | 100% | 16% |
| TP=2 | GPU 1 | 112 | 4.15 | 4.22 | 78% | 65% | 58 | 1062 | 100% | 20% |
| TP=2+SP | GPU 0 | 158 | 4.06 | 5.74 | 88% | 56% | 70 | 1195 | 100% | 50% |
| TP=2+SP | GPU 1 | 158 | 4.06 | 5.74 | 87% | 54% | 61 | 1312 | 100% | 55% |

</details>

### `256:1024:8:4:2` · 20.8M params · mb=64

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 96 | 84,906 | 84,906 | 10.83 | 10.83 | 16.7% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 108 | 151,463 | 75,732 | 19.32 | 9.66 | 14.9% | 1.78× | 89% |  |
| ZeRO-1 (opt state) | 2 | 127 | 129,262 | 64,631 | 16.49 | 8.24 | 12.7% | 1.52× | 76% |  |
| ZeRO-2 (+grads) | 2 | 121 | 135,008 | 67,504 | 17.22 | 8.61 | 13.2% | 1.59× | 80% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 211 | 77,813 | 38,906 | 9.92 | 4.96 | 7.6% | 0.92× | 46% |  |
| TP=2 | 2 | 89 | 92,446 | 46,223 | 11.79 | 5.90 | 9.1% | 1.09× | 54% |  |
| TP=2+SP | 2 | 132 | 61,975 | 30,988 | 7.90 | 3.95 | 6.1% | 0.73× | 36% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.083 | 0.166 | 0.27 | 2.84 | 3.71 | – |
| DDP (ZeRO-0) | 0.083 | 0.166 | 0.27 | 2.84 | 3.71 | +0% |
| ZeRO-1 (opt state) | 0.083 | 0.083 | 0.18 | 2.76 | 2.89 | -3% |
| ZeRO-2 (+grads) | 0.083 | 0.083 | 0.18 | 2.76 | 2.94 | -3% |
| ZeRO-3 (+params) | 0.042 | 0.083 | 0.15 | 3.56 | 3.65 | +25% |
| TP=2 | 0.067 | 0.135 | 0.22 | 2.49 | 3.35 | -12% |
| TP=2+SP | 0.067 | 0.135 | 0.22 | 2.40 | 3.24 | -16% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 79% | 60% | 64 | 862 | 67 | 99% | 37% | 6% | 0% | 57% |
| DDP (ZeRO-0) | 84% | 54% | 59 | 1043 | 57 | 100% | 24% | 4% | 28% | 43% |
| ZeRO-1 (opt state) | 85% | 48% | 60 | 1212 | 58 | 100% | 14% | 2% | 45% | 39% |
| ZeRO-2 (+grads) | 84% | 50% | 64 | 1091 | 58 | 100% | 15% | 2% | 45% | 38% |
| ZeRO-3 (+params) | 84% | 64% | 66 | 1341 | 59 | 100% | 9% | 2% | 51% | 38% |
| TP=2 | 80% | 53% | 66 | 1130 | 59 | 100% | 25% | 3% | 20% | 52% |
| TP=2+SP | 84% | 44% | 62 | 1374 | 59 | 100% | 12% | 1% | 56% | 30% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 108 | 2.84 | 3.69 | 84% | 57% | 55 | 920 | 100% | 25% |
| DDP (ZeRO-0) | GPU 1 | 108 | 2.84 | 3.71 | 86% | 51% | 63 | 1167 | 100% | 32% |
| ZeRO-1 (opt state) | GPU 0 | 126 | 2.76 | 2.89 | 91% | 47% | 54 | 1095 | 100% | 58% |
| ZeRO-1 (opt state) | GPU 1 | 127 | 2.76 | 2.89 | 80% | 48% | 65 | 1330 | 100% | 32% |
| ZeRO-2 (+grads) | GPU 0 | 121 | 2.76 | 2.94 | 96% | 49% | 66 | 1077 | 100% | 42% |
| ZeRO-2 (+grads) | GPU 1 | 121 | 2.76 | 2.94 | 73% | 50% | 63 | 1104 | 100% | 47% |
| ZeRO-3 (+params) | GPU 0 | 211 | 3.56 | 3.65 | 84% | 65% | 63 | 1269 | 100% | 59% |
| ZeRO-3 (+params) | GPU 1 | 210 | 3.56 | 3.65 | 84% | 64% | 68 | 1412 | 100% | 42% |
| TP=2 | GPU 0 | 89 | 2.49 | 3.35 | 83% | 54% | 71 | 1099 | 100% | 19% |
| TP=2 | GPU 1 | 88 | 2.49 | 3.35 | 76% | 52% | 61 | 1161 | 100% | 21% |
| TP=2+SP | GPU 0 | 132 | 2.40 | 3.24 | 85% | 43% | 61 | 1341 | 100% | 55% |
| TP=2+SP | GPU 1 | 132 | 2.40 | 3.24 | 84% | 44% | 63 | 1408 | 100% | 57% |

</details>

### `256:1024:8:4:2` · 20.8M params · mb=128

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 182 | 90,200 | 90,200 | 11.50 | 11.50 | 17.7% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 195 | 167,740 | 83,870 | 21.39 | 10.70 | 16.5% | 1.86× | 93% |  |
| ZeRO-1 (opt state) | 2 | 220 | 148,931 | 74,465 | 18.99 | 9.50 | 14.6% | 1.65× | 83% |  |
| ZeRO-2 (+grads) | 2 | 214 | 152,768 | 76,384 | 19.48 | 9.74 | 15.0% | 1.69× | 85% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 332 | 98,790 | 49,395 | 12.60 | 6.30 | 9.7% | 1.10× | 55% |  |
| TP=2 | 2 | 168 | 97,470 | 48,735 | 12.43 | 6.22 | 9.6% | 1.08× | 54% |  |
| TP=2+SP | 2 | 238 | 68,706 | 34,353 | 8.76 | 4.38 | 6.7% | 0.76× | 38% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.083 | 0.166 | 0.27 | 5.39 | 7.19 | – |
| DDP (ZeRO-0) | 0.083 | 0.166 | 0.27 | 5.39 | 7.19 | +0% |
| ZeRO-1 (opt state) | 0.083 | 0.083 | 0.18 | 5.31 | 5.56 | -2% |
| ZeRO-2 (+grads) | 0.083 | 0.083 | 0.18 | 5.31 | 5.56 | -2% |
| ZeRO-3 (+params) | 0.042 | 0.083 | 0.15 | 6.83 | 8.67 | +27% |
| TP=2 | 0.067 | 0.135 | 0.22 | 4.73 | 6.43 | -12% |
| TP=2+SP | 0.067 | 0.135 | 0.22 | 4.54 | 6.23 | -16% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 92% | 69% | 66 | 763 | 68 | 99% | 48% | 6% | 0% | 46% |
| DDP (ZeRO-0) | 91% | 64% | 67 | 942 | 58 | 100% | 35% | 5% | 23% | 37% |
| ZeRO-1 (opt state) | 91% | 56% | 60 | 906 | 59 | 100% | 26% | 4% | 34% | 36% |
| ZeRO-2 (+grads) | 91% | 58% | 66 | 939 | 59 | 100% | 28% | 4% | 31% | 37% |
| ZeRO-3 (+params) | 94% | 79% | 66 | 1135 | 61 | 100% | 14% | 2% | 38% | 44% |
| TP=2 | 89% | 62% | 65 | 1050 | 60 | 100% | 32% | 3% | 26% | 40% |
| TP=2+SP | 92% | 49% | 63 | 1260 | 60 | 100% | 13% | 1% | 62% | 23% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 195 | 5.39 | 7.19 | 91% | 63% | 68 | 814 | 100% | 15% |
| DDP (ZeRO-0) | GPU 1 | 195 | 5.39 | 7.19 | 91% | 65% | 66 | 1069 | 100% | 30% |
| ZeRO-1 (opt state) | GPU 0 | 220 | 5.31 | 5.56 | 89% | 55% | 64 | 803 | 100% | 25% |
| ZeRO-1 (opt state) | GPU 1 | 220 | 5.31 | 5.56 | 93% | 58% | 56 | 1009 | 100% | 44% |
| ZeRO-2 (+grads) | GPU 0 | 214 | 5.31 | 5.56 | 87% | 57% | 68 | 826 | 100% | 17% |
| ZeRO-2 (+grads) | GPU 1 | 214 | 5.31 | 5.56 | 95% | 59% | 63 | 1052 | 100% | 45% |
| ZeRO-3 (+params) | GPU 0 | 332 | 6.83 | 8.67 | 94% | 80% | 65 | 1014 | 100% | 32% |
| ZeRO-3 (+params) | GPU 1 | 332 | 6.83 | 8.67 | 93% | 79% | 67 | 1256 | 100% | 45% |
| TP=2 | GPU 0 | 168 | 4.73 | 6.43 | 89% | 63% | 68 | 940 | 100% | 20% |
| TP=2 | GPU 1 | 167 | 4.73 | 6.43 | 89% | 61% | 63 | 1159 | 100% | 31% |
| TP=2+SP | GPU 0 | 238 | 4.54 | 6.23 | 92% | 49% | 65 | 1204 | 100% | 63% |
| TP=2+SP | GPU 1 | 238 | 4.54 | 6.23 | 92% | 48% | 62 | 1316 | 100% | 62% |

</details>

### `384:1536:8:6:2` · 36.6M params · mb=64

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 144 | 56,987 | 56,987 | 12.78 | 12.78 | 19.7% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 167 | 97,918 | 48,959 | 21.97 | 10.98 | 16.9% | 1.72× | 86% |  |
| ZeRO-1 (opt state) | 2 | 192 | 85,375 | 42,687 | 19.15 | 9.58 | 14.7% | 1.50× | 75% |  |
| ZeRO-2 (+grads) | 2 | 177 | 92,522 | 46,261 | 20.76 | 10.38 | 16.0% | 1.62× | 81% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 274 | 59,822 | 29,911 | 13.42 | 6.71 | 10.3% | 1.05× | 52% |  |
| TP=2 | 2 | 124 | 66,047 | 33,023 | 14.82 | 7.41 | 11.4% | 1.16× | 58% |  |
| TP=2+SP | 2 | 183 | 44,679 | 22,339 | 10.02 | 5.01 | 7.7% | 0.78× | 39% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.147 | 0.293 | 0.47 | 3.54 | 4.30 | – |
| DDP (ZeRO-0) | 0.147 | 0.293 | 0.47 | 3.54 | 4.30 | +0% |
| ZeRO-1 (opt state) | 0.147 | 0.147 | 0.32 | 3.40 | 3.51 | -4% |
| ZeRO-2 (+grads) | 0.147 | 0.147 | 0.31 | 3.39 | 3.59 | -4% |
| ZeRO-3 (+params) | 0.073 | 0.147 | 0.25 | 4.54 | 5.29 | +28% |
| TP=2 | 0.112 | 0.224 | 0.36 | 2.94 | 3.78 | -17% |
| TP=2+SP | 0.112 | 0.224 | 0.36 | 2.79 | 3.60 | -21% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 91% | 61% | 67 | 738 | 70 | 100% | 47% | 6% | 0% | 47% |
| DDP (ZeRO-0) | 90% | 56% | 59 | 992 | 59 | 100% | 31% | 4% | 31% | 34% |
| ZeRO-1 (opt state) | 89% | 48% | 62 | 1057 | 59 | 100% | 21% | 3% | 42% | 34% |
| ZeRO-2 (+grads) | 90% | 50% | 59 | 1042 | 59 | 100% | 22% | 3% | 40% | 35% |
| ZeRO-3 (+params) | 92% | 71% | 64 | 1220 | 60 | 100% | 13% | 2% | 46% | 38% |
| TP=2 | 86% | 56% | 64 | 1093 | 60 | 100% | 29% | 3% | 30% | 39% |
| TP=2+SP | 90% | 43% | 66 | 1325 | 60 | 100% | 14% | 1% | 59% | 25% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 167 | 3.54 | 4.27 | 90% | 56% | 60 | 899 | 100% | 26% |
| DDP (ZeRO-0) | GPU 1 | 167 | 3.54 | 4.30 | 90% | 57% | 58 | 1084 | 100% | 36% |
| ZeRO-1 (opt state) | GPU 0 | 192 | 3.40 | 3.51 | 93% | 47% | 62 | 987 | 100% | 46% |
| ZeRO-1 (opt state) | GPU 1 | 192 | 3.40 | 3.51 | 86% | 48% | 62 | 1126 | 100% | 38% |
| ZeRO-2 (+grads) | GPU 0 | 177 | 3.39 | 3.59 | 96% | 50% | 61 | 961 | 100% | 48% |
| ZeRO-2 (+grads) | GPU 1 | 177 | 3.39 | 3.59 | 85% | 51% | 58 | 1122 | 100% | 31% |
| ZeRO-3 (+params) | GPU 0 | 274 | 4.54 | 5.29 | 93% | 71% | 64 | 1132 | 100% | 54% |
| ZeRO-3 (+params) | GPU 1 | 274 | 4.54 | 5.29 | 91% | 71% | 65 | 1308 | 100% | 38% |
| TP=2 | GPU 0 | 124 | 2.94 | 3.78 | 85% | 55% | 63 | 990 | 100% | 33% |
| TP=2 | GPU 1 | 124 | 2.94 | 3.78 | 87% | 57% | 65 | 1196 | 100% | 27% |
| TP=2+SP | GPU 0 | 183 | 2.79 | 3.60 | 89% | 42% | 68 | 1268 | 100% | 58% |
| TP=2+SP | GPU 1 | 183 | 2.79 | 3.60 | 90% | 43% | 63 | 1382 | 100% | 60% |

</details>

### `384:1536:8:6:2` · 36.6M params · mb=128

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 276 | 59,447 | 59,447 | 13.34 | 13.34 | 20.5% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 299 | 109,652 | 54,826 | 24.60 | 12.30 | 18.9% | 1.84× | 92% |  |
| ZeRO-1 (opt state) | 2 | 325 | 100,915 | 50,458 | 22.64 | 11.32 | 17.4% | 1.70× | 85% |  |
| ZeRO-2 (+grads) | 2 | 312 | 104,967 | 52,483 | 23.55 | 11.77 | 18.1% | 1.77× | 88% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 488 | 67,093 | 33,547 | 15.05 | 7.53 | 11.6% | 1.13× | 56% |  |
| TP=2 | 2 | 246 | 66,620 | 33,310 | 14.95 | 7.47 | 11.5% | 1.12× | 56% |  |
| TP=2+SP | 2 | 351 | 46,629 | 23,315 | 10.46 | 5.23 | 8.0% | 0.78× | 39% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.147 | 0.293 | 0.46 | 6.49 | 8.10 | – |
| DDP (ZeRO-0) | 0.147 | 0.293 | 0.46 | 6.49 | 8.10 | +0% |
| ZeRO-1 (opt state) | 0.147 | 0.147 | 0.32 | 6.34 | 6.51 | -2% |
| ZeRO-2 (+grads) | 0.147 | 0.147 | 0.31 | 6.34 | 6.56 | -2% |
| ZeRO-3 (+params) | 0.073 | 0.147 | 0.25 | 8.57 | 10.17 | +32% |
| TP=2 | 0.112 | 0.224 | 0.36 | 5.46 | 7.14 | -16% |
| TP=2+SP | 0.112 | 0.224 | 0.36 | 5.17 | 6.80 | -20% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 95% | 59% | 67 | 704 | 70 | 100% | 57% | 6% | 0% | 37% |
| DDP (ZeRO-0) | 95% | 56% | 63 | 929 | 59 | 100% | 41% | 5% | 24% | 29% |
| ZeRO-1 (opt state) | 95% | 51% | 65 | 965 | 60 | 100% | 33% | 4% | 33% | 30% |
| ZeRO-2 (+grads) | 95% | 53% | 62 | 906 | 61 | 100% | 34% | 4% | 31% | 31% |
| ZeRO-3 (+params) | 96% | 77% | 65 | 1074 | 62 | 100% | 19% | 2% | 34% | 43% |
| TP=2 | 92% | 56% | 66 | 994 | 62 | 100% | 36% | 3% | 34% | 28% |
| TP=2+SP | 96% | 45% | 64 | 1246 | 62 | 100% | 17% | 1% | 63% | 19% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 299 | 6.49 | 8.10 | 95% | 56% | 62 | 804 | 100% | 15% |
| DDP (ZeRO-0) | GPU 1 | 299 | 6.49 | 8.10 | 95% | 57% | 64 | 1053 | 100% | 34% |
| ZeRO-1 (opt state) | GPU 0 | 325 | 6.34 | 6.51 | 94% | 52% | 65 | 849 | 100% | 21% |
| ZeRO-1 (opt state) | GPU 1 | 325 | 6.34 | 6.51 | 95% | 51% | 65 | 1081 | 100% | 46% |
| ZeRO-2 (+grads) | GPU 0 | 312 | 6.34 | 6.56 | 94% | 52% | 59 | 781 | 100% | 24% |
| ZeRO-2 (+grads) | GPU 1 | 312 | 6.34 | 6.56 | 95% | 54% | 65 | 1032 | 100% | 39% |
| ZeRO-3 (+params) | GPU 0 | 488 | 8.57 | 10.17 | 96% | 77% | 65 | 920 | 100% | 25% |
| ZeRO-3 (+params) | GPU 1 | 488 | 8.57 | 10.17 | 97% | 76% | 66 | 1229 | 100% | 42% |
| TP=2 | GPU 0 | 246 | 5.46 | 7.14 | 90% | 54% | 67 | 841 | 100% | 22% |
| TP=2 | GPU 1 | 243 | 5.46 | 7.14 | 93% | 57% | 64 | 1146 | 100% | 45% |
| TP=2+SP | GPU 0 | 351 | 5.17 | 6.80 | 95% | 46% | 64 | 1168 | 100% | 61% |
| TP=2+SP | GPU 1 | 351 | 5.17 | 6.80 | 96% | 44% | 64 | 1324 | 100% | 65% |

</details>

### `512:2048:8:8:2` · 56.2M params · mb=64

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 201 | 40,730 | 40,730 | 13.98 | 13.98 | 21.5% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 237 | 69,192 | 34,596 | 23.74 | 11.87 | 18.3% | 1.70× | 85% |  |
| ZeRO-1 (opt state) | 2 | 261 | 62,733 | 31,367 | 21.53 | 10.76 | 16.6% | 1.54× | 77% |  |
| ZeRO-2 (+grads) | 2 | 239 | 68,566 | 34,283 | 23.53 | 11.76 | 18.1% | 1.68× | 84% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 359 | 45,592 | 22,796 | 15.65 | 7.82 | 12.0% | 1.12× | 56% |  |
| TP=2 | 2 | 164 | 50,062 | 25,031 | 17.18 | 8.59 | 13.2% | 1.23× | 61% |  |
| TP=2+SP | 2 | 232 | 35,240 | 17,620 | 12.09 | 6.05 | 9.3% | 0.87× | 43% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.225 | 0.449 | 0.69 | 4.23 | 4.94 | – |
| DDP (ZeRO-0) | 0.225 | 0.449 | 0.69 | 4.23 | 4.94 | +0% |
| ZeRO-1 (opt state) | 0.225 | 0.225 | 0.47 | 4.01 | 4.20 | -5% |
| ZeRO-2 (+grads) | 0.225 | 0.225 | 0.47 | 4.01 | 4.31 | -5% |
| ZeRO-3 (+params) | 0.112 | 0.225 | 0.37 | 5.50 | 6.25 | +30% |
| TP=2 | 0.164 | 0.328 | 0.51 | 3.39 | 4.15 | -20% |
| TP=2+SP | 0.164 | 0.328 | 0.51 | 3.20 | 3.84 | -24% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 95% | 58% | 63 | 740 | 72 | 100% | 55% | 6% | 0% | 39% |
| DDP (ZeRO-0) | 94% | 52% | 63 | 1021 | 60 | 100% | 35% | 4% | 33% | 29% |
| ZeRO-1 (opt state) | 95% | 46% | 62 | 989 | 61 | 100% | 26% | 3% | 43% | 28% |
| ZeRO-2 (+grads) | 95% | 49% | 66 | 974 | 61 | 100% | 28% | 3% | 41% | 28% |
| ZeRO-3 (+params) | 95% | 70% | 65 | 1151 | 62 | 100% | 15% | 2% | 44% | 38% |
| TP=2 | 90% | 55% | 63 | 1015 | 61 | 100% | 30% | 3% | 34% | 33% |
| TP=2+SP | 94% | 44% | 66 | 1250 | 61 | 100% | 14% | 2% | 62% | 22% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 237 | 4.23 | 4.94 | 93% | 51% | 64 | 940 | 100% | 26% |
| DDP (ZeRO-0) | GPU 1 | 237 | 4.23 | 4.94 | 94% | 52% | 63 | 1102 | 100% | 39% |
| ZeRO-1 (opt state) | GPU 0 | 261 | 4.01 | 4.20 | 96% | 45% | 63 | 862 | 100% | 43% |
| ZeRO-1 (opt state) | GPU 1 | 261 | 4.01 | 4.20 | 93% | 46% | 60 | 1117 | 100% | 43% |
| ZeRO-2 (+grads) | GPU 0 | 239 | 4.01 | 4.31 | 95% | 48% | 67 | 878 | 100% | 36% |
| ZeRO-2 (+grads) | GPU 1 | 239 | 4.01 | 4.31 | 94% | 50% | 66 | 1069 | 100% | 45% |
| ZeRO-3 (+params) | GPU 0 | 359 | 5.50 | 6.25 | 95% | 70% | 64 | 1020 | 100% | 47% |
| ZeRO-3 (+params) | GPU 1 | 359 | 5.50 | 6.25 | 95% | 70% | 65 | 1281 | 100% | 42% |
| TP=2 | GPU 0 | 164 | 3.39 | 4.15 | 90% | 55% | 64 | 918 | 100% | 20% |
| TP=2 | GPU 1 | 163 | 3.39 | 4.15 | 90% | 56% | 63 | 1111 | 100% | 48% |
| TP=2+SP | GPU 0 | 232 | 3.20 | 3.84 | 94% | 44% | 67 | 1167 | 100% | 61% |
| TP=2+SP | GPU 1 | 232 | 3.20 | 3.84 | 94% | 43% | 65 | 1334 | 100% | 63% |

</details>

### `512:2048:8:8:2` · 56.2M params · mb=128

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 387 | 42,363 | 42,363 | 14.54 | 14.54 | 22.4% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 420 | 77,927 | 38,963 | 26.74 | 13.37 | 20.6% | 1.84× | 92% |  |
| ZeRO-1 (opt state) | 2 | 451 | 72,712 | 36,356 | 24.95 | 12.48 | 19.2% | 1.72× | 86% |  |
| ZeRO-2 (+grads) | 2 | 444 | 73,753 | 36,877 | 25.31 | 12.65 | 19.5% | 1.74× | 87% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 665 | 49,264 | 24,632 | 16.91 | 8.45 | 13.0% | 1.16× | 58% |  |
| TP=2 | 2 | 321 | 51,078 | 25,539 | 17.53 | 8.76 | 13.5% | 1.21× | 60% |  |
| TP=2+SP | 2 | 458 | 35,788 | 17,894 | 12.28 | 6.14 | 9.4% | 0.84× | 42% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.225 | 0.449 | 0.69 | 7.60 | 9.14 | – |
| DDP (ZeRO-0) | 0.225 | 0.449 | 0.69 | 7.60 | 9.14 | +0% |
| ZeRO-1 (opt state) | 0.225 | 0.225 | 0.47 | 7.38 | 7.57 | -3% |
| ZeRO-2 (+grads) | 0.225 | 0.225 | 0.47 | 7.38 | 7.57 | -3% |
| ZeRO-3 (+params) | 0.112 | 0.225 | 0.37 | 10.31 | 11.86 | +36% |
| TP=2 | 0.164 | 0.328 | 0.51 | 6.19 | 7.89 | -19% |
| TP=2+SP | 0.164 | 0.328 | 0.51 | 5.81 | 7.43 | -24% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 97% | 55% | 66 | 663 | 71 | 100% | 64% | 6% | 0% | 30% |
| DDP (ZeRO-0) | 97% | 51% | 65 | 895 | 60 | 100% | 46% | 5% | 26% | 24% |
| ZeRO-1 (opt state) | 97% | 48% | 64 | 864 | 62 | 100% | 37% | 4% | 35% | 24% |
| ZeRO-2 (+grads) | 97% | 48% | 64 | 820 | 63 | 100% | 40% | 4% | 32% | 25% |
| ZeRO-3 (+params) | 98% | 73% | 66 | 1026 | 64 | 100% | 21% | 2% | 37% | 39% |
| TP=2 | 95% | 52% | 66 | 933 | 63 | 100% | 42% | 3% | 28% | 26% |
| TP=2+SP | 96% | 44% | 65 | 1244 | 64 | 100% | 17% | 1% | 65% | 16% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 420 | 7.60 | 9.14 | 97% | 51% | 67 | 746 | 100% | 15% |
| DDP (ZeRO-0) | GPU 1 | 420 | 7.60 | 9.14 | 97% | 52% | 64 | 1044 | 100% | 36% |
| ZeRO-1 (opt state) | GPU 0 | 451 | 7.38 | 7.57 | 97% | 48% | 64 | 727 | 100% | 32% |
| ZeRO-1 (opt state) | GPU 1 | 450 | 7.38 | 7.57 | 97% | 48% | 63 | 1002 | 100% | 39% |
| ZeRO-2 (+grads) | GPU 0 | 444 | 7.38 | 7.57 | 97% | 47% | 66 | 677 | 100% | 26% |
| ZeRO-2 (+grads) | GPU 1 | 444 | 7.38 | 7.57 | 97% | 49% | 62 | 963 | 100% | 37% |
| ZeRO-3 (+params) | GPU 0 | 665 | 10.31 | 11.86 | 98% | 73% | 66 | 843 | 100% | 24% |
| ZeRO-3 (+params) | GPU 1 | 665 | 10.31 | 11.86 | 98% | 73% | 66 | 1210 | 100% | 50% |
| TP=2 | GPU 0 | 321 | 6.19 | 7.89 | 95% | 51% | 67 | 785 | 100% | 22% |
| TP=2 | GPU 1 | 316 | 6.19 | 7.89 | 94% | 53% | 64 | 1080 | 100% | 35% |
| TP=2+SP | GPU 0 | 458 | 5.81 | 7.43 | 96% | 43% | 65 | 1144 | 100% | 61% |
| TP=2+SP | GPU 1 | 458 | 5.81 | 7.43 | 97% | 45% | 65 | 1343 | 100% | 68% |

</details>

### `512:2048:12:8:2` · 71.4M params · mb=64

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 273 | 30,062 | 30,062 | 13.15 | 13.15 | 20.2% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 315 | 52,061 | 26,030 | 22.78 | 11.39 | 17.5% | 1.73× | 87% |  |
| ZeRO-1 (opt state) | 2 | 350 | 46,801 | 23,401 | 20.48 | 10.24 | 15.8% | 1.56× | 78% |  |
| ZeRO-2 (+grads) | 2 | 329 | 49,828 | 24,914 | 21.80 | 10.90 | 16.8% | 1.66× | 83% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 493 | 33,240 | 16,620 | 14.54 | 7.27 | 11.2% | 1.11× | 55% |  |
| TP=2 | 2 | 223 | 36,682 | 18,341 | 16.05 | 8.02 | 12.3% | 1.22× | 61% |  |
| TP=2+SP | 2 | 325 | 25,174 | 12,587 | 11.01 | 5.51 | 8.5% | 0.84× | 42% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.286 | 0.571 | 0.87 | 5.30 | 5.96 | – |
| DDP (ZeRO-0) | 0.286 | 0.571 | 0.87 | 5.30 | 5.96 | +0% |
| ZeRO-1 (opt state) | 0.286 | 0.286 | 0.59 | 5.02 | 5.37 | -5% |
| ZeRO-2 (+grads) | 0.286 | 0.286 | 0.59 | 5.02 | 5.37 | -5% |
| ZeRO-3 (+params) | 0.143 | 0.286 | 0.47 | 7.19 | 7.93 | +36% |
| TP=2 | 0.194 | 0.389 | 0.60 | 4.07 | 4.78 | -23% |
| TP=2+SP | 0.194 | 0.389 | 0.60 | 3.77 | 4.49 | -29% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 95% | 57% | 66 | 729 | 73 | 100% | 54% | 6% | 0% | 40% |
| DDP (ZeRO-0) | 94% | 50% | 66 | 977 | 60 | 100% | 34% | 4% | 31% | 30% |
| ZeRO-1 (opt state) | 94% | 45% | 61 | 1026 | 61 | 100% | 25% | 3% | 42% | 29% |
| ZeRO-2 (+grads) | 94% | 48% | 61 | 1010 | 62 | 100% | 28% | 3% | 38% | 31% |
| ZeRO-3 (+params) | 95% | 72% | 66 | 1153 | 63 | 100% | 14% | 2% | 43% | 39% |
| TP=2 | 88% | 52% | 68 | 1006 | 62 | 100% | 31% | 3% | 29% | 36% |
| TP=2+SP | 93% | 41% | 65 | 1368 | 62 | 100% | 13% | 2% | 65% | 21% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 315 | 5.30 | 5.96 | 94% | 50% | 68 | 841 | 100% | 26% |
| DDP (ZeRO-0) | GPU 1 | 315 | 5.30 | 5.96 | 94% | 51% | 63 | 1113 | 100% | 37% |
| ZeRO-1 (opt state) | GPU 0 | 350 | 5.02 | 5.37 | 97% | 45% | 61 | 876 | 100% | 40% |
| ZeRO-1 (opt state) | GPU 1 | 350 | 5.02 | 5.37 | 92% | 45% | 61 | 1175 | 100% | 44% |
| ZeRO-2 (+grads) | GPU 0 | 329 | 5.02 | 5.37 | 94% | 47% | 63 | 916 | 100% | 28% |
| ZeRO-2 (+grads) | GPU 1 | 329 | 5.02 | 5.37 | 93% | 49% | 59 | 1105 | 100% | 48% |
| ZeRO-3 (+params) | GPU 0 | 493 | 7.19 | 7.93 | 95% | 72% | 65 | 1012 | 100% | 37% |
| ZeRO-3 (+params) | GPU 1 | 493 | 7.19 | 7.93 | 95% | 72% | 67 | 1295 | 100% | 50% |
| TP=2 | GPU 0 | 223 | 4.07 | 4.78 | 87% | 52% | 67 | 880 | 100% | 25% |
| TP=2 | GPU 1 | 221 | 4.07 | 4.78 | 89% | 53% | 70 | 1131 | 100% | 34% |
| TP=2+SP | GPU 0 | 325 | 3.77 | 4.49 | 93% | 41% | 66 | 1283 | 100% | 64% |
| TP=2+SP | GPU 1 | 325 | 3.77 | 4.49 | 94% | 40% | 64 | 1452 | 100% | 66% |

</details>

### `512:2048:12:8:2` · 71.4M params · mb=128

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 514 | 31,879 | 31,879 | 13.95 | 13.95 | 21.5% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 565 | 57,972 | 28,986 | 25.36 | 12.68 | 19.5% | 1.82× | 91% |  |
| ZeRO-1 (opt state) | 2 | 610 | 53,729 | 26,864 | 23.51 | 11.75 | 18.1% | 1.69× | 84% |  |
| ZeRO-2 (+grads) | 2 | 595 | 55,069 | 27,535 | 24.09 | 12.05 | 18.5% | 1.73× | 86% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 938 | 34,927 | 17,463 | 15.28 | 7.64 | 11.8% | 1.10× | 55% |  |
| TP=2 | 2 | 417 | 39,297 | 19,649 | 17.19 | 8.60 | 13.2% | 1.23× | 62% |  |
| TP=2+SP | 2 | 629 | 26,029 | 13,014 | 11.39 | 5.69 | 8.8% | 0.82× | 41% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.286 | 0.571 | 0.87 | 9.53 | 10.87 | – |
| DDP (ZeRO-0) | 0.286 | 0.571 | 0.87 | 9.53 | 10.87 | +0% |
| ZeRO-1 (opt state) | 0.286 | 0.286 | 0.59 | 9.25 | 10.83 | -3% |
| ZeRO-2 (+grads) | 0.286 | 0.286 | 0.59 | 9.25 | 10.83 | -3% |
| ZeRO-3 (+params) | 0.143 | 0.286 | 0.47 | 13.55 | 13.66 | +42% |
| TP=2 | 0.194 | 0.389 | 0.60 | 7.44 | 9.08 | -22% |
| TP=2+SP | 0.194 | 0.389 | 0.60 | 6.85 | 8.39 | -28% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 97% | 54% | 66 | 658 | 72 | 100% | 62% | 7% | 0% | 31% |
| DDP (ZeRO-0) | 97% | 50% | 64 | 838 | 61 | 100% | 45% | 5% | 25% | 25% |
| ZeRO-1 (opt state) | 97% | 47% | 60 | 916 | 63 | 100% | 35% | 4% | 36% | 25% |
| ZeRO-2 (+grads) | 97% | 48% | 62 | 862 | 64 | 100% | 38% | 4% | 32% | 25% |
| ZeRO-3 (+params) | 98% | 73% | 66 | 975 | 66 | 100% | 19% | 2% | 37% | 40% |
| TP=2 | 94% | 50% | 66 | 954 | 64 | 100% | 37% | 3% | 34% | 25% |
| TP=2+SP | 96% | 42% | 67 | 1303 | 64 | 100% | 14% | 1% | 68% | 16% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 565 | 9.53 | 10.87 | 97% | 50% | 66 | 681 | 100% | 16% |
| DDP (ZeRO-0) | GPU 1 | 565 | 9.53 | 10.87 | 96% | 50% | 62 | 996 | 100% | 34% |
| ZeRO-1 (opt state) | GPU 0 | 610 | 9.25 | 10.83 | 96% | 47% | 59 | 764 | 100% | 31% |
| ZeRO-1 (opt state) | GPU 1 | 610 | 9.25 | 10.83 | 98% | 47% | 61 | 1068 | 100% | 40% |
| ZeRO-2 (+grads) | GPU 0 | 595 | 9.25 | 10.83 | 97% | 47% | 64 | 696 | 100% | 19% |
| ZeRO-2 (+grads) | GPU 1 | 595 | 9.25 | 10.83 | 97% | 48% | 61 | 1028 | 100% | 45% |
| ZeRO-3 (+params) | GPU 0 | 938 | 13.55 | 13.66 | 98% | 73% | 65 | 743 | 100% | 23% |
| ZeRO-3 (+params) | GPU 1 | 938 | 13.55 | 13.66 | 98% | 74% | 68 | 1207 | 100% | 51% |
| TP=2 | GPU 0 | 417 | 7.44 | 9.08 | 95% | 49% | 66 | 800 | 100% | 24% |
| TP=2 | GPU 1 | 411 | 7.44 | 9.08 | 94% | 51% | 66 | 1108 | 100% | 44% |
| TP=2+SP | GPU 0 | 629 | 6.85 | 8.39 | 96% | 41% | 68 | 1214 | 100% | 65% |
| TP=2+SP | GPU 1 | 629 | 6.85 | 8.39 | 97% | 42% | 66 | 1392 | 100% | 70% |

</details>

### `768:3072:12:12:4` · 142.5M params · mb=64

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 492 | 16,649 | 16,649 | 14.46 | 14.46 | 22.2% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 569 | 28,795 | 14,397 | 25.01 | 12.51 | 19.2% | 1.73× | 86% |  |
| ZeRO-1 (opt state) | 2 | 624 | 26,244 | 13,122 | 22.80 | 11.40 | 17.5% | 1.58× | 79% |  |
| ZeRO-2 (+grads) | 2 | 591 | 27,699 | 13,850 | 24.06 | 12.03 | 18.5% | 1.66× | 83% |  |
| ZeRO-3 (+params) `[eager]` | 2 | 842 | 19,458 | 9,729 | 16.90 | 8.45 | 13.0% | 1.17× | 58% |  |
| TP=2 | 2 | 346 | 23,653 | 11,827 | 20.55 | 10.27 | 15.8% | 1.42× | 71% |  |
| TP=2+SP | 2 | 496 | 16,505 | 8,253 | 14.34 | 7.17 | 11.0% | 0.99× | 50% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.570 | 1.140 | 1.77 | 7.62 | 8.56 | – |
| DDP (ZeRO-0) | 0.570 | 1.140 | 1.77 | 7.62 | 8.56 | +0% |
| ZeRO-1 (opt state) | 0.570 | 0.570 | 1.19 | 7.04 | 7.70 | -8% |
| ZeRO-2 (+grads) | 0.570 | 0.570 | 1.18 | 7.03 | 7.71 | -8% |
| ZeRO-3 (+params) | 0.285 | 0.570 | 0.98 | 10.36 | 10.77 | +36% |
| TP=2 | 0.362 | 0.725 | 1.14 | 5.55 | 5.99 | -27% |
| TP=2+SP | 0.362 | 0.725 | 1.13 | 5.11 | 5.40 | -33% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 98% | 51% | 66 | 645 | 75 | 100% | 65% | 6% | 0% | 29% |
| DDP (ZeRO-0) | 98% | 44% | 63 | 928 | 62 | 100% | 40% | 4% | 36% | 21% |
| ZeRO-1 (opt state) | 99% | 40% | 62 | 970 | 64 | 100% | 32% | 3% | 45% | 20% |
| ZeRO-2 (+grads) | 98% | 40% | 64 | 924 | 65 | 100% | 35% | 3% | 40% | 22% |
| ZeRO-3 (+params) | 97% | 65% | 65 | 1051 | 66 | 100% | 18% | 2% | 47% | 32% |
| TP=2 | 95% | 51% | 65 | 974 | 64 | 100% | 36% | 3% | 35% | 26% |
| TP=2+SP | 96% | 42% | 65 | 1317 | 64 | 100% | 15% | 1% | 66% | 17% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 569 | 7.62 | 8.56 | 98% | 46% | 65 | 766 | 100% | 25% |
| DDP (ZeRO-0) | GPU 1 | 569 | 7.62 | 8.56 | 98% | 43% | 61 | 1090 | 100% | 46% |
| ZeRO-1 (opt state) | GPU 0 | 624 | 7.04 | 7.70 | 98% | 40% | 64 | 807 | 100% | 39% |
| ZeRO-1 (opt state) | GPU 1 | 624 | 7.04 | 7.70 | 99% | 40% | 60 | 1133 | 100% | 52% |
| ZeRO-2 (+grads) | GPU 0 | 591 | 7.03 | 7.71 | 99% | 41% | 65 | 751 | 100% | 30% |
| ZeRO-2 (+grads) | GPU 1 | 591 | 7.03 | 7.71 | 98% | 40% | 62 | 1098 | 100% | 50% |
| ZeRO-3 (+params) | GPU 0 | 842 | 10.36 | 10.77 | 97% | 66% | 65 | 823 | 100% | 36% |
| ZeRO-3 (+params) | GPU 1 | 842 | 10.36 | 10.77 | 97% | 65% | 65 | 1279 | 100% | 58% |
| TP=2 | GPU 0 | 346 | 5.55 | 5.99 | 95% | 51% | 65 | 798 | 100% | 21% |
| TP=2 | GPU 1 | 341 | 5.55 | 5.99 | 95% | 51% | 65 | 1150 | 100% | 49% |
| TP=2+SP | GPU 0 | 496 | 5.11 | 5.40 | 96% | 42% | 66 | 1205 | 100% | 63% |
| TP=2+SP | GPU 1 | 496 | 5.11 | 5.40 | 96% | 42% | 63 | 1430 | 100% | 70% |

</details>

### `768:3072:12:12:4` · 142.5M params · mb=128

**Throughput & efficiency**

| Mode | GPUs | Step ms | tok/s | tok/s/GPU | TFLOPS | TFLOPS/GPU | MFU | Speedup | Scaling eff. | Note |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 1 | 974 | 16,821 | 16,821 | 14.61 | 14.61 | 22.5% | 1.00× | 100% |  |
| DDP (ZeRO-0) | 2 | 1073 | 30,533 | 15,266 | 26.52 | 13.26 | 20.4% | 1.82× | 91% |  |
| ZeRO-1 (opt state) | 2 | 1152 | 28,437 | 14,219 | 24.70 | 12.35 | 19.0% | 1.69× | 85% |  |
| ZeRO-2 (+grads) | 2 | 1091 | 30,043 | 15,022 | 26.10 | 13.05 | 20.1% | 1.79× | 89% |  |
| ZeRO-3 (+params) | 2 | – | – | – | – | – | – | – | – | **OOM** CUDA out of memory |
| TP=2 | 2 | 685 | 23,905 | 11,952 | 20.76 | 10.38 | 16.0% | 1.42× | 71% |  |
| TP=2+SP | 2 | 965 | 16,974 | 8,487 | 14.74 | 7.37 | 11.3% | 1.01× | 50% |  |

**Memory per GPU (GB)**

| Mode | Params | Optimizer state | Static (after step) | Peak allocated | Peak reserved | Peak vs DDP-0 |
|:--|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 0.570 | 1.140 | 1.73 | 13.15 | 14.19 | – |
| DDP (ZeRO-0) | 0.570 | 1.140 | 1.73 | 13.15 | 14.19 | +0% |
| ZeRO-1 (opt state) | 0.570 | 0.570 | 1.19 | 12.62 | 14.17 | -4% |
| ZeRO-2 (+grads) | 0.570 | 0.570 | 1.18 | 12.61 | 14.16 | -4% |
| TP=2 | 0.362 | 0.725 | 1.13 | 9.77 | 10.97 | -26% |
| TP=2+SP | 0.362 | 0.725 | 1.13 | 8.90 | 10.23 | -32% |

**GPU utilization & kernel breakdown (mean over GPUs)**

| Mode | GPU util | Mem-ctrl util | Power W | SM clock MHz | Temp °C | Kernel busy | Matmul | Attention | NCCL | Other |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 GPU (baseline) | 99% | 50% | 66 | 584 | 76 | 100% | 71% | 6% | 0% | 22% |
| DDP (ZeRO-0) | 99% | 45% | 63 | 847 | 63 | 100% | 49% | 4% | 30% | 17% |
| ZeRO-1 (opt state) | 99% | 41% | 62 | 861 | 66 | 100% | 42% | 4% | 37% | 17% |
| ZeRO-2 (+grads) | 99% | 43% | 62 | 838 | 66 | 100% | 45% | 4% | 33% | 18% |
| TP=2 | 97% | 52% | 64 | 919 | 65 | 100% | 43% | 3% | 33% | 20% |
| TP=2+SP | 98% | 42% | 67 | 1257 | 66 | 100% | 18% | 1% | 67% | 14% |

<details><summary>Per-GPU breakdown</summary>

| Mode | GPU | Step ms | Peak alloc GB | Peak reserved GB | GPU util | Mem-ctrl util | Power W | SM MHz | Kernel busy | NCCL |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| DDP (ZeRO-0) | GPU 0 | 1073 | 13.15 | 14.19 | 99% | 45% | 65 | 648 | 100% | 14% |
| DDP (ZeRO-0) | GPU 1 | 1073 | 13.15 | 14.19 | 99% | 45% | 61 | 1046 | 100% | 46% |
| ZeRO-1 (opt state) | GPU 0 | 1152 | 12.62 | 14.17 | 100% | 42% | 64 | 651 | 100% | 23% |
| ZeRO-1 (opt state) | GPU 1 | 1152 | 12.62 | 14.17 | 99% | 40% | 60 | 1072 | 100% | 52% |
| ZeRO-2 (+grads) | GPU 0 | 1091 | 12.61 | 14.16 | 100% | 44% | 65 | 643 | 100% | 20% |
| ZeRO-2 (+grads) | GPU 1 | 1091 | 12.61 | 14.16 | 99% | 42% | 59 | 1033 | 100% | 46% |
| TP=2 | GPU 0 | 685 | 9.77 | 10.97 | 97% | 52% | 66 | 754 | 100% | 22% |
| TP=2 | GPU 1 | 675 | 9.77 | 10.97 | 97% | 51% | 63 | 1084 | 100% | 44% |
| TP=2+SP | GPU 0 | 965 | 8.90 | 10.23 | 98% | 43% | 66 | 1142 | 100% | 64% |
| TP=2+SP | GPU 1 | 965 | 8.90 | 10.23 | 98% | 42% | 68 | 1372 | 100% | 70% |

</details>

## 6. Skipped / failed runs

| Shape | MB | Mode | Status | Reason |
|:--|--:|--:|--:|--:|
| `768:3072:12:12:4` | 128 | ZeRO-3 (+params) | OOM | CUDA out of memory |
